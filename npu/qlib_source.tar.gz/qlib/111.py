import re, shutil
from pathlib import Path
import qlib, os

# 自动定位你环境里 qlib 的模型目录
MODEL_DIR = Path(os.path.dirname(qlib.__file__)) / "contrib" / "model"

RULES = [
    # 1) 设备字符串："cuda:%d" / "cuda:%s" / "cuda" → npu
    (re.compile(r'"cuda:%d"'), '"npu:%d"'),
    (re.compile(r'"cuda:%s"'), '"npu:%s"'),
    (re.compile(r'(?<=device = )"cuda"(?= if)'), '"npu"'),   # pytorch_tra.py
    # 2) CUDA API → NPU API
    (re.compile(r'torch\.cuda\.is_available\(\)'), 'torch.npu.is_available()'),
    (re.compile(r'torch\.cuda\.empty_cache\(\)'), 'torch.npu.empty_cache()'),
    (re.compile(r'torch\.cuda\.ma：nual_seed_all'), 'torch.npu.manual_seed_all'),
    (re.compile(r'torch\.cuda\.set_device'), 'torch.npu.set_device'),
]

for f in sorted(MODEL_DIR.glob("pytorch_*.py")):
    src = f.read_text(encoding="utf-8")
    out = src
    for pat, rep in RULES:
        out = pat.sub(rep, out)
    if out != src:
        shutil.copy2(f, f.with_suffix(".py.bak"))   # 自动备份
        f.write_text(out, encoding="utf-8")
        print(f"patched {f.name}")
