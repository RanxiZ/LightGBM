#!/usr/bin/env bash
# ============================================================================
# replace_gru_npu.sh — 一键把 Qlib 的 nn.GRU 替换为 AscendC 融合 GRU 算子
#
# 用法:
#   bash replace_gru_npu.sh                       # 在线安装（自动从 GitHub 下载）
#   bash replace_gru_npu.sh /path/to/main.tar.gz  # 离线安装（手动下载的压缩包）
#   bash replace_gru_npu.sh /path/to/GRU_evo...   # 离线安装（已解压的目录）
#   bash replace_gru_npu.sh --uninstall
#
# 原理:
#   1) 从 https://github.com/Liziqi-77/AI-Infra 下载
#      AscendC_ops/GRU_evo_20261012_110616_final（最终 2.05x 变体）
#   2) 用 cmake 编译出 gru_ext*.so（注册 torch.ops.npu.gru / gru_backward）
#   3) 向当前 python 的 site-packages 写入 gru_npu_patch.py + .pth 自启动文件，
#      monkeypatch torch.nn.GRU.forward：NPU 上单层 batch_first 时走融合算子，
#      其余情况回落原生实现。补丁只影响 nn.GRU，不改 qlib 任何源码。
#
# 注意:
#   * 融合算子是【单层专用】，反向不计算 dx，Qlib GRU 默认 num_layers=2
#     无法使用。请在你的 workflow yaml 的 model kwargs 里加  num_layers: 1
#   * 若芯片不是 Ascend950PR_9579，可通过环境变量 SOC_VERSION=xxx 指定
# ============================================================================
set -euo pipefail

REPO_URL="https://github.com/Liziqi-77/AI-Infra"
SUBDIR="AscendC_ops/GRU_evo_20261012_110616_final"
INSTALL_DIR="${GRU_PATCH_DIR:-$HOME/.qlib_gru_ascendc}"
PYBIN="${PYTHON:-$(command -v python3)}"

log()  { echo -e "\033[32m[replace_gru_npu]\033[0m $*"; }
warn() { echo -e "\033[33m[replace_gru_npu]\033[0m $*"; }
die()  { echo -e "\033[31m[replace_gru_npu][ERROR]\033[0m $*"; exit 1; }

# ---------------------------------------------------------------------------
# 卸载
# ---------------------------------------------------------------------------
if [ "${1:-}" = "--uninstall" ]; then
    SP="$("$PYBIN" -c 'import sysconfig; print(sysconfig.get_paths()["purelib"])')"
    rm -f "$SP/gru_npu_patch.py" "$SP/gru_npu_patch.pth"
    rm -rf "$INSTALL_DIR"
    log "已卸载：删除 $SP/gru_npu_patch.{py,pth} 与 $INSTALL_DIR"
    exit 0
fi

# ---------------------------------------------------------------------------
# 0. 前置检查：自动定位能 import torch + torch_npu 的解释器
# ---------------------------------------------------------------------------
command -v curl  >/dev/null || die "需要 curl"
command -v cmake >/dev/null || die "需要 cmake"

pick_python() {
    # 依次探测候选解释器，返回第一个能同时 import torch / torch_npu 的
    local cands=()
    [ -n "${PYTHON:-}" ] && cands+=("$PYTHON")
    # 常见安装位置（按优先级），包括报错堆栈里出现过的 /usr/local/python3.12.13
    for d in /usr/local/python3*/bin /usr/local/bin /opt/conda/bin /usr/bin; do
        for p in "$d"/python3 "$d"/python3.1* "$d"/python; do
            [ -x "$p" ] && cands+=("$p")
        done
    done
    # PATH 里的所有 python3
    while IFS= read -r p; do cands+=("$p"); done < <(compgen -c python3 | sort -u | while read -r n; do command -v "$n" 2>/dev/null; done)
    local seen="" p
    for p in "${cands[@]}"; do
        case "$seen" in *"|$p|"*) continue;; esac
        seen="$seen|$p|"
        [ -x "$p" ] || continue
        if "$p" -c "import torch, torch_npu" >/dev/null 2>&1; then
            echo "$p"; return 0
        fi
    done
    return 1
}

if ! PYBIN="$(pick_python)"; then
    die "未找到能 import torch/torch_npu 的 python。请显式指定：export PYTHON=/path/to/python3 后重试"
fi
log "选定解释器: $PYBIN ($("$PYBIN" -c 'import torch; print("torch", torch.__version__)'))"

# ---------------------------------------------------------------------------
# 1. 获取算子源码（在线下载 或 离线本地包）
# ---------------------------------------------------------------------------
SRC_ARG="${1:-}"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

find_subdir() {  # 在给定根目录下定位包含 kernel/op_kernel 的算子源码目录
    local root="$1"
    if [ -d "$root/kernel/op_kernel" ]; then
        echo "$root"; return 0
    fi
    local hit
    hit="$(find "$root" -maxdepth 4 -type d -name op_kernel -path "*/kernel/*" 2>/dev/null | head -1 || true)"
    if [ -n "$hit" ]; then
        echo "$(dirname "$(dirname "$hit")")"; return 0
    fi
    return 1
}

if [ -n "$SRC_ARG" ]; then
    # ---- 离线模式 ----
    [ -e "$SRC_ARG" ] || die "指定的路径不存在: $SRC_ARG"
    log "步骤 1/5 使用本地源码包: $SRC_ARG"
    if [ -d "$SRC_ARG" ]; then
        SRC="$(find_subdir "$SRC_ARG")" || die "目录 $SRC_ARG 中未找到算子源码（应包含 kernel/op_kernel）"
    else
        tar -xzf "$SRC_ARG" -C "$TMP" 2>/dev/null \
            || (mkdir -p "$TMP/x" && tar -xzf "$SRC_ARG" -C "$TMP/x") \
            || die "解压失败: $SRC_ARG"
        SRC="$(find_subdir "$TMP")" || SRC="$(find_subdir "$TMP/x")" \
            || die "压缩包中未找到算子源码（解压后应有某个目录包含 kernel/op_kernel）"
    fi
else
    # ---- 在线模式 ----
    log "步骤 1/5 下载算子源码 ..."
    curl -fSL "$REPO_URL/archive/refs/heads/main.tar.gz" -o "$TMP/repo.tar.gz" \
        || die "下载失败。环境访问 GitHub 受限时，请在可上网的机器下载
        $REPO_URL/archive/refs/heads/main.tar.gz
    拷贝到本机后运行: bash replace_gru_npu.sh /path/to/main.tar.gz"
    tar -xzf "$TMP/repo.tar.gz" -C "$TMP"
    SRC="$TMP/AI-Infra-main/$SUBDIR"
    [ -d "$SRC/kernel/op_kernel" ] || die "仓库目录结构不符，未找到 $SUBDIR/kernel"
fi
log "源码目录: $SRC"

rm -rf "$INSTALL_DIR"
mkdir -p "$INSTALL_DIR"
cp -r "$SRC/kernel" "$INSTALL_DIR/kernel"
cp "$SRC/model_new_ascendc.py" "$INSTALL_DIR/" 2>/dev/null || true
log "源码已放到 $INSTALL_DIR"

# ---------------------------------------------------------------------------
# 2. 环境探测（CANN / SOC_VERSION / python）
# ---------------------------------------------------------------------------
log "步骤 2/5 探测编译环境 ..."
CANN_PATH="${ASCEND_HOME_PATH:-}"
if [ -z "$CANN_PATH" ] || [ ! -d "$CANN_PATH" ]; then
    CANN_PATH="$(ls -d /usr/local/Ascend/cann-* /usr/local/Ascend/ascend-toolkit/latest 2>/dev/null | sort -V | tail -1 || true)"
fi
[ -n "$CANN_PATH" ] && [ -d "$CANN_PATH" ] || die "未找到 CANN 安装目录，请 export ASCEND_HOME_PATH=/usr/local/Ascend/cann-x.x.x"

if [ -z "${SOC_VERSION:-}" ]; then
    SOC_VERSION="$("$PYBIN" - <<'PYEOF' 2>/dev/null || true
import torch, torch_npu
print(torch.npu.get_device_name(0))
PYEOF
)"
fi
if [ -z "${SOC_VERSION:-}" ]; then
    SOC_VERSION="$(npu-smi info -t board -i 0 2>/dev/null | grep -oP 'Ascend\w+' | head -1 || true)"
fi
[ -n "${SOC_VERSION:-}" ] || die "无法自动识别 SOC_VERSION，请手动 export SOC_VERSION=Ascend950PR_9579 后重试"
[ "$SOC_VERSION" = "Ascend950PR_9579" ] || warn "该算子最优变体针对 Ascend950PR_9579 调优，当前识别为 $SOC_VERSION，仍可编译但性能未必最优"

# cmake 内部会调裸 python3，保证它解析到我们选定的解释器
export PATH="$(dirname "$(readlink -f "$PYBIN")"):$PATH"
export SOC_VERSION
export ASCEND_HOME_PATH="$CANN_PATH"
# shellcheck disable=SC1091
[ -f "$CANN_PATH/set_env.sh" ] && source "$CANN_PATH/set_env.sh" >/dev/null 2>&1 || true

log "SOC_VERSION=$SOC_VERSION"
log "CANN     =$CANN_PATH"
log "python3  =$(command -v python3)"

# ---------------------------------------------------------------------------
# 3. 编译内核
# ---------------------------------------------------------------------------
log "步骤 3/5 编译 AscendC 内核（首次约数分钟）..."
rm -rf "$INSTALL_DIR/kernel/build"
cmake -S "$INSTALL_DIR/kernel" -B "$INSTALL_DIR/kernel/build" \
      -DSOC_VERSION="$SOC_VERSION" \
      -DASCEND_CANN_PACKAGE_PATH="$CANN_PATH" \
      -DCMAKE_BUILD_TYPE=Release > "$TMP/cmake.log" 2>&1 \
    || { tail -30 "$TMP/cmake.log"; die "cmake 配置失败"; }
make -C "$INSTALL_DIR/kernel/build" -j"$(nproc)" > "$TMP/make.log" 2>&1 \
    || { tail -30 "$TMP/make.log"; die "编译失败"; }
SO_FILE="$(ls "$INSTALL_DIR"/kernel/build/gru_ext*.so 2>/dev/null | head -1 || true)"
[ -n "$SO_FILE" ] || die "编译结束但未找到 gru_ext*.so"
log "编译完成: $SO_FILE"

# ---------------------------------------------------------------------------
# 4. 安装 monkeypatch（site-packages 自启动）
# ---------------------------------------------------------------------------
log "步骤 4/5 安装 python 补丁 ..."
SP="$("$PYBIN" -c 'import sysconfig; print(sysconfig.get_paths()["purelib"])')"

cat > "$SP/gru_npu_patch.py" <<PYEOF
# Auto-generated by replace_gru_npu.sh — do not edit by hand.
"""Monkeypatch torch.nn.GRU.forward：NPU 上单层 batch_first 时调用
AscendC 融合算子 torch.ops.npu.gru / gru_backward，其余情况走原生实现。"""
import glob
import os

import torch
import torch.nn as nn

_KERNEL_BUILD_DIR = r"""${INSTALL_DIR}/kernel/build"""
_ext_loaded = False


def _load_ext():
    global _ext_loaded
    if _ext_loaded:
        return
    sos = sorted(glob.glob(os.path.join(_KERNEL_BUILD_DIR, "gru_ext*.so")))
    if not sos:
        raise RuntimeError(
            "gru_npu_patch: 未找到 gru_ext*.so，请重新运行 replace_gru_npu.sh"
        )
    torch.ops.load_library(sos[0])
    _ext_loaded = True


class _FusedGRU(torch.autograd.Function):
    """融合前向 + 反向。反向只产出权重梯度（dW_ih, dW_hh, db_ih, db_hh），
    不计算 dx / dh0 —— 训练特征 x 不需要梯度，与 qlib 场景一致。"""

    @staticmethod
    def forward(ctx, x, w_ih, w_hh, b_ih, b_hh):
        out = torch.ops.npu.gru(x, w_ih, w_hh, b_ih, b_hh)
        ctx.save_for_backward(x, out, w_ih, w_hh, b_ih, b_hh)
        return out

    @staticmethod
    def backward(ctx, grad_out):
        x, out, w_ih, w_hh, b_ih, b_hh = ctx.saved_tensors
        dW_ih, dW_hh, db_ih, db_hh = torch.ops.npu.gru_backward(
            grad_out.to(torch.float32), x.to(torch.float32), out.to(torch.float32),
            w_ih.to(torch.float32), w_hh.to(torch.float32),
            b_ih.to(torch.float32), b_hh.to(torch.float32),
        )
        return None, dW_ih, dW_hh, db_ih, db_hh


_orig_gru_forward = nn.GRU.forward


def _npu_gru_forward(self, input, hx=None):
    is_npu = getattr(input, "is_npu", None)
    if is_npu is None:
        is_npu = input.device.type == "npu"
    if not is_npu:
        return _orig_gru_forward(self, input, hx)

    if self.num_layers != 1 or not self.batch_first:
        raise NotImplementedError(
            "AscendC 融合 GRU 仅支持单层 batch_first；当前 num_layers=%s, "
            "batch_first=%s。请在 workflow 配置中把 model 的 num_layers 设为 1。"
            % (self.num_layers, self.batch_first)
        )
    if hx is not None:
        raise NotImplementedError("AscendC 融合 GRU 暂不支持自定义初始隐状态 hx")

    if self.bias:
        b_ih, b_hh = self.bias_ih_l0, self.bias_hh_l0
    else:
        z = torch.zeros(3 * self.hidden_size, device=input.device, dtype=input.dtype)
        b_ih, b_hh = z, z

    _load_ext()
    out = _FusedGRU.apply(input, self.weight_ih_l0, self.weight_hh_l0, b_ih, b_hh)
    h_n = out[:, -1, :].unsqueeze(0).contiguous()  # [1, B, H]
    return out, h_n


if not getattr(nn.GRU, "_npu_fused_patched", False):
    nn.GRU.forward = _npu_gru_forward
    nn.GRU._npu_fused_patched = True
PYEOF

# .pth 文件以 "import " 开头时会在 python 启动时自动执行 —— qrun 无需任何改动
echo "import gru_npu_patch" > "$SP/gru_npu_patch.pth"
log "已写入 $SP/gru_npu_patch.py 与 gru_npu_patch.pth（python 启动时自动加载）"

# ---------------------------------------------------------------------------
# 5. 自检：融合算子 vs CPU 原生 GRU 前向 + 反向梯度
# ---------------------------------------------------------------------------
log "步骤 5/5 自检（对比 CPU 原生 GRU）..."
"$PYBIN" - <<'PYEOF'
import torch, torch.nn as nn
import gru_npu_patch  # noqa: F401  (启动时也会自动加载)

torch.manual_seed(0)
B, S, I, H = 4, 16, 6, 64
rnn = nn.GRU(I, H, num_layers=1, batch_first=True)
x = torch.randn(B, S, I)
ref_out, _ = rnn(x)

dev = "npu:0"
rnn_npu = nn.GRU(I, H, num_layers=1, batch_first=True)
rnn_npu.load_state_dict(rnn.state_dict())
rnn_npu.to(dev)
xn = x.to(dev)
out, hn = rnn_npu(xn)
err = (out.cpu() - ref_out).abs().max().item()
print(f"[selfcheck] 前向 max|diff| = {err:.3e}")
assert err < 1e-2, "前向误差过大"

# 反向：权重梯度对比
g = torch.randn_like(ref_out)
ref_out.backward(g)
ref_gW_ih = rnn.weight_ih_l0.grad.clone()
rnn_npu.zero_grad()
out.backward(g.to(dev))
got = rnn_npu.weight_ih_l0.grad.cpu()
gerr = (got - ref_gW_ih).abs().max().item()
rel = gerr / (ref_gW_ih.abs().max().item() + 1e-12)
print(f"[selfcheck] 反向 dW_ih rel err = {rel:.3e}")
assert rel < 1e-2, "反向梯度误差过大"
print("[selfcheck] PASS — 补丁生效")
PYEOF

cat <<EOF

==============================================================================
安装完成。之后直接运行 qrun 即可，无需改 qlib 源码。

重要：该融合算子仅支持【单层】 GRU，Qlib 默认 num_layers=2 会抛
NotImplementedError。请在 workflow yaml 的 model kwargs 中加一行：

    model:
        class: GRU
        module_path: qlib.contrib.model.pytorch_gru
        kwargs:
            num_layers: 1        <-- 新增

撤销安装: bash replace_gru_npu.sh --uninstall
==============================================================================
EOF
