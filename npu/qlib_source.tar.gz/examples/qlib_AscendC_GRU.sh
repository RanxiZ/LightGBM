#!/usr/bin/env bash
# =============================================================================
# 一键脚本：编译 AscendC 融合 GRU 算子，并替换 qlib 中的 nn.GRU
#
# 算子来源: https://github.com/Liziqi-77/AI-Infra
#           AscendC_ops/NN_GRU_ascendc_build/kernel
# 目标文件: qlib/contrib/model/pytorch_gru.py
#
# 使用方法（所有参数均通过命令行传入，无需改脚本）:
#   bash qlib_AscendC_GRU.sh \
#       --soc Ascend910B2 \
#       --ascend-home /usr/local/Ascend/ascend-toolkit/latest \
#       --python /path/to/bin/python3 \
#       --workdir ~/ascendc_gru \
#       [--no-verify] [--repo-url <git地址>]
#
# 也可用同名大写环境变量兜底: SOC_VERSION / ASCEND_HOME_PATH / PYTHON / WORKDIR
# 查看帮助: bash qlib_AscendC_GRU.sh --help
#
# 前置条件:
#   - 已安装 CANN (ascend-toolkit)
#   - --python 指向的环境已安装: torch, torch_npu, pybind11, qlib
#   - 已安装 cmake(>=3.16), make, git
# =============================================================================
set -euo pipefail

usage() {
    cat <<'EOF'
用法: bash qlib_AscendC_GRU.sh [选项]

选项:
  --soc <型号>          芯片型号。不传则自动通过 npu-smi 探测。
                        示例: Ascend910B2 / Ascend910_9391 / Ascend950DT_9571
                        (950 系列格式为 "芯片名_NPU编号",
                         可用 npu-smi info -t board -i <设备id> 查看)
  --ascend-home <路径>  CANN 安装路径 (默认: /usr/local/Ascend/ascend-toolkit/latest)
  --python <路径>       安装了 qlib 和 torch_npu 的 python (默认: python3)
  --workdir <路径>      算子源码与编译产物目录 (默认: ~/ascendc_gru)
  --repo-url <地址>     算子仓库地址 (默认: https://github.com/Liziqi-77/AI-Infra.git)
  --no-verify           跳过替换后的数值正确性校验
  --check               只做环境探测: 打印各参数取值和建议命令, 不做任何修改
  -h, --help            显示本帮助
EOF
    exit 0
}

# 通过 npu-smi 自动探测 SOC_VERSION
#   A2 (910B):  "Ascend" + Name          如 Ascend910B2
#   A3 / 950:   Chip Name + "_" + NPU Name  如 Ascend910_9391 / Ascend950DT_9571
detect_soc() {
    command -v npu-smi >/dev/null 2>&1 || return 1
    local nid info chip ctype npu
    nid=$(npu-smi info -l 2>/dev/null | grep -m1 'NPU ID' | cut -d: -f2 | tr -d ' ')
    [ -n "$nid" ] || return 1
    info=$(npu-smi info -t board -i "$nid" 2>/dev/null)
    chip=$(echo "$info" | grep -m1 'Chip Name' | cut -d: -f2 | tr -d ' ')
    npu=$(echo "$info" | grep -m1 'NPU Name' | cut -d: -f2 | tr -d ' ')
    if [ -z "$chip" ]; then   # A2/310P 等需要带 chip id 查询
        info=$(npu-smi info -t board -i "$nid" -c 0 2>/dev/null)
        chip=$(echo "$info" | grep -m1 'Chip Name' | cut -d: -f2 | tr -d ' ')
        ctype=$(echo "$info" | grep -m1 'Chip Type' | cut -d: -f2 | tr -d ' ')
        npu=$(echo "$info" | grep -m1 'NPU Name' | cut -d: -f2 | tr -d ' ')
    fi
    [ -n "$chip" ] || return 1
    case "$chip" in
        Ascend*) : ;;
        *)       chip="${ctype:-Ascend}${chip}" ;;
    esac
    case "$chip" in
        *950*|*910_93*) [ -n "$npu" ] && chip="${chip}_${npu}" ;;
    esac
    # 规范化大小写: ascend950dt -> Ascend950DT, ascend910b2 -> Ascend910B2
    chip=$(echo "$chip" | sed -E 's/^ascend/Ascend/I; s/950dt/950DT/I; s/950pr/950PR/I; s/910b/910B/I; s/310p/310P/I')
    [ -n "$chip" ] && echo "$chip"
}

# ======================= 参数解析（命令行 > 环境变量 > 自动探测/默认值） ======
WORKDIR="${WORKDIR:-$HOME/ascendc_gru}"
SOC_VERSION="${SOC_VERSION:-}"                          # 留空则自动探测
ASCEND_HOME_PATH="${ASCEND_HOME_PATH:-/usr/local/Ascend/ascend-toolkit/latest}"
PYTHON="${PYTHON:-python3}"
REPO_URL="${REPO_URL:-https://github.com/Liziqi-77/AI-Infra.git}"
KERNEL_SUBDIR="AscendC_ops/NN_GRU_ascendc_build/kernel"
RUN_VERIFY="${RUN_VERIFY:-1}"
CHECK_ONLY=0

while [ $# -gt 0 ]; do
    case "$1" in
        --soc)         SOC_VERSION="$2"; shift 2 ;;
        --ascend-home) ASCEND_HOME_PATH="$2"; shift 2 ;;
        --python)      PYTHON="$2"; shift 2 ;;
        --workdir)     WORKDIR="$2"; shift 2 ;;
        --repo-url)    REPO_URL="$2"; shift 2 ;;
        --no-verify)   RUN_VERIFY=0; shift ;;
        --check)       CHECK_ONLY=1; shift ;;
        -h|--help)     usage ;;
        *) echo "[ERROR] 未知参数: $1 (用 --help 查看用法)" >&2; exit 1 ;;
    esac
done

if [ -z "$SOC_VERSION" ]; then
    SOC_VERSION="$(detect_soc || true)"
    [ -n "$SOC_VERSION" ] || die "无法通过 npu-smi 自动探测芯片型号，请用 --soc 手动指定"
    echo "[INFO] 自动探测到 SOC_VERSION=$SOC_VERSION"
fi

# --------------------------- --check 模式: 只探测不修改 ----------------------
if [ "$CHECK_ONLY" = "1" ]; then
    echo "============================= 环境探测结果 ============================="
    echo "[芯片] SOC_VERSION     : $SOC_VERSION"
    if command -v npu-smi >/dev/null 2>&1; then
        _nid=$(npu-smi info -l 2>/dev/null | grep -m1 'NPU ID' | cut -d: -f2 | tr -d ' ')
        echo "--- npu-smi info -t board -i ${_nid:-0} ---"
        npu-smi info -t board -i "${_nid:-0}" 2>/dev/null || true
    else
        echo "[芯片] npu-smi 不存在!"
    fi
    echo "------------------------------------------------------------------------"
    if [ -d "$ASCEND_HOME_PATH" ]; then
        echo "[CANN] ASCEND_HOME_PATH: $ASCEND_HOME_PATH (存在)"
    else
        echo "[CANN] ASCEND_HOME_PATH: $ASCEND_HOME_PATH (不存在! 需用 --ascend-home 指定)"
    fi
    for _t in cmake make git; do
        if command -v "$_t" >/dev/null 2>&1; then
            echo "[工具] $_t: $(command -v $_t) ($($_t --version 2>/dev/null | head -n1))"
        else
            echo "[工具] $_t: 未安装!"
        fi
    done
    echo "------------------------------------------------------------------------"
    echo "[Python] 解释器: $PYTHON -> $(command -v "$PYTHON" 2>/dev/null || echo '不存在!')"
    "$PYTHON" - <<'PYEOF' 2>/dev/null || echo "[Python] 无法执行, 请检查 --python 路径"
import importlib.util, sys
print("[Python] 版本:", sys.version.split()[0])
for p in ["torch", "torch_npu", "pybind11", "qlib"]:
    spec = importlib.util.find_spec(p)
    if spec is None:
        print(f"[Python] 包 {p}: 未安装!")
    else:
        try:
            mod = __import__(p)
            print(f"[Python] 包 {p}: {getattr(mod, '__version__', '?')}")
        except Exception as e:
            print(f"[Python] 包 {p}: 已安装但 import 失败 ({e})")
PYEOF
    echo "======================================================================="
    echo "建议执行命令:"
    echo "  bash $0 --soc $SOC_VERSION --ascend-home $ASCEND_HOME_PATH --python $PYTHON --workdir $WORKDIR"
    exit 0
fi
# =============================================================================

log()  { echo -e "\033[1;32m[STEP]\033[0m $*"; }
warn() { echo -e "\033[1;33m[WARN]\033[0m $*"; }
die()  { echo -e "\033[1;31m[ERROR]\033[0m $*" >&2; exit 1; }

export ASCEND_HOME_PATH SOC_VERSION

# -----------------------------------------------------------------------------
# 0. 加载 CANN 环境
# -----------------------------------------------------------------------------
log "0/5 加载 CANN 环境 (ASCEND_HOME_PATH=$ASCEND_HOME_PATH)"
if [ -f "$ASCEND_HOME_PATH/../set_env.sh" ]; then
    # shellcheck disable=SC1091
    source "$ASCEND_HOME_PATH/../set_env.sh"
elif [ -f /usr/local/Ascend/ascend-toolkit/set_env.sh ]; then
    # shellcheck disable=SC1091
    source /usr/local/Ascend/ascend-toolkit/set_env.sh
else
    warn "未找到 set_env.sh，假定 CANN 环境变量已配置"
fi
export ASCEND_HOME_PATH SOC_VERSION
[ -d "$ASCEND_HOME_PATH" ] || die "ASCEND_HOME_PATH 目录不存在: $ASCEND_HOME_PATH"

# -----------------------------------------------------------------------------
# 1. 依赖检查
# -----------------------------------------------------------------------------
log "1/5 检查依赖 (cmake / make / git / python 包)"
command -v cmake >/dev/null || die "缺少 cmake"
command -v make  >/dev/null || die "缺少 make"
command -v git   >/dev/null || die "缺少 git"
$PYTHON - <<'PYEOF' || die "python 依赖不完整，请先 pip 安装缺失的包"
import importlib, sys
missing = [p for p in ["torch", "torch_npu", "pybind11", "qlib"] if importlib.util.find_spec(p) is None]
if missing:
    print("缺失包:", missing)
    sys.exit(1)
import torch, torch_npu
print("torch:", torch.__version__, "| torch_npu:", torch_npu.__version__)
PYEOF

# -----------------------------------------------------------------------------
# 2. 拉取算子源码（sparse checkout，只下载 kernel 目录）
# -----------------------------------------------------------------------------
log "2/5 拉取算子源码到 $WORKDIR"
mkdir -p "$WORKDIR"
if [ ! -d "$WORKDIR/AI-Infra/.git" ]; then
    git clone --depth 1 --filter=blob:none --sparse "$REPO_URL" "$WORKDIR/AI-Infra"
    git -C "$WORKDIR/AI-Infra" sparse-checkout set "$KERNEL_SUBDIR"
else
    warn "源码已存在，跳过 clone（如需更新请删除 $WORKDIR/AI-Infra 后重跑）"
fi
KERNEL_DIR="$WORKDIR/AI-Infra/$KERNEL_SUBDIR"
[ -f "$KERNEL_DIR/CMakeLists.txt" ] || die "算子源码不完整: $KERNEL_DIR"

# -----------------------------------------------------------------------------
# 3. 编译算子（cmake + make，产物为 build/gru_ext*.so）
# -----------------------------------------------------------------------------
log "3/5 编译 AscendC 算子 (SOC_VERSION=$SOC_VERSION)"
case "$SOC_VERSION" in
    *950*)
        warn "=========================================================="
        warn "检测到 Ascend 950 (AIC-C-310 / dav-3510 架构)。"
        warn "该算子仓库默认面向 Atlas A2 (dav-c220 / Ascend910B) 开发，"
        warn "在 950 上编译需要支持 dav-3510 的 CANN (8.5+/9.0+)，"
        warn "且 kernel 内的 tiling/UB 假设是针对 A2 的，若编译报错"
        warn "'Unsupported NPU architecture or soc' 或数值校验不过，"
        warn "说明该算子尚未适配 950，需要改造 kernel 源码。"
        warn "==========================================================" ;;
esac
mkdir -p "$KERNEL_DIR/build"

# 算子的 CMakeLists.txt 内部写死调用 "python3" 来定位 torch/torch_npu/pybind11,
# 这里做一个 shim 目录把 python3 指向 --python 传入的解释器, 避免用到系统 python。
SHIM_DIR="$WORKDIR/.pyshim"
mkdir -p "$SHIM_DIR"
PYTHON_BIN="$(command -v "$PYTHON" || true)"
[ -n "$PYTHON_BIN" ] || die "找不到解释器: $PYTHON"
ln -sf "$PYTHON_BIN" "$SHIM_DIR/python3"
ln -sf "$PYTHON_BIN" "$SHIM_DIR/python"
export PATH="$SHIM_DIR:$PATH"
log "python3 已指向: $PYTHON_BIN ($("$SHIM_DIR/python3" -c 'import sys; print(sys.version.split()[0])'))"

# 清理旧的 cmake 缓存, 避免上次失败的配置残留
rm -rf "$KERNEL_DIR/build"
mkdir -p "$KERNEL_DIR/build"

cmake -S "$KERNEL_DIR" -B "$KERNEL_DIR/build" \
    -DSOC_VERSION="$SOC_VERSION" \
    -DASCEND_CANN_PACKAGE_PATH="$ASCEND_HOME_PATH" \
    -DCMAKE_BUILD_TYPE=Release
make -C "$KERNEL_DIR/build" -j"$(nproc)"

SO_PATH="$(ls "$KERNEL_DIR"/build/gru_ext*.so 2>/dev/null | head -n 1)"
[ -n "$SO_PATH" ] || die "编译完成但未找到 gru_ext*.so"
log "算子编译成功: $SO_PATH"

# -----------------------------------------------------------------------------
# 4. 打补丁：修改 qlib/contrib/model/pytorch_gru.py
#    - 设备 cuda -> npu
#    - GRUModel 改用 torch.ops.npu.gru 融合算子（自动封装 autograd）
#    - empty_cache 适配 NPU
#    原文件自动备份为 *.bak_算子替换
# -----------------------------------------------------------------------------
log "4/5 打补丁到 qlib (pytorch_gru*.py + pytorch_alstm*.py)"
# 用 find_spec 定位 qlib 模型目录, 避免真正 import qlib (其 __init__ 可能有额外依赖导致失败)
MODEL_DIR="$($PYTHON - <<'PYEOF'
import importlib.util, os
spec = importlib.util.find_spec("qlib")
if spec is None or not spec.submodule_search_locations:
    raise SystemExit(1)
d = os.path.join(list(spec.submodule_search_locations)[0], "contrib", "model")
print(d if os.path.isdir(d) else "")
PYEOF
)"
[ -n "$MODEL_DIR" ] && [ -d "$MODEL_DIR" ] || die "找不到 qlib 的 contrib/model 目录
  请检查: $PYTHON -c \"import importlib.util; print(importlib.util.find_spec('qlib'))\"
  若 qlib 未 pip 安装而是源码目录, 请先 cd 到源码根目录再运行本脚本,
  或在 qlib 源码环境里执行: pip install -e ."
log "目标目录: $MODEL_DIR"

MODEL_DIR="$MODEL_DIR" SO_PATH="$SO_PATH" $PYTHON - <<'PYEOF'
import os, re, shutil, sys

model_dir = os.environ["MODEL_DIR"]
so_path = os.environ["SO_PATH"]
MARK = "AscendC fused GRU patch"

# (文件名, 变体, 补丁块插入锚点)
#   gru_plain  : 输入 [N,F*T] 需 reshape; 整体替换 GRUModel
#   gru_ts     : 输入 [N,T,F] 无需 reshape; 整体替换 GRUModel
#   alstm_plain: ALSTMModel 内含 fc_in->GRU->attention; 定点替换 rnn 调用行
#   alstm_ts   : 同上, forward 无 reshape
TARGETS = [
    ("pytorch_gru.py", "gru_plain", "class GRU(Model):"),
    ("pytorch_gru_ts.py", "gru_ts", "class GRU(Model):"),
    ("pytorch_alstm.py", "alstm_plain", "class ALSTM(Model):"),
    ("pytorch_alstm_ts.py", "alstm_ts", "class ALSTM(Model):"),
]

PATCH_BLOCK = f'''
# ====================== {MARK} ======================
# 由一键脚本自动插入。恢复方法: 用同目录 .bak_算子替换 备份覆盖本文件。
import os as _os

_GRU_EXT_SO = _os.environ.get("GRU_EXT_SO", r"{so_path}")
_NPU_GRU_AVAILABLE = False
try:
    import torch_npu  # noqa: F401
    if _os.path.exists(_GRU_EXT_SO):
        torch.ops.load_library(_GRU_EXT_SO)
        _NPU_GRU_AVAILABLE = True
except Exception as _e:
    print("[qlib GRU NPU patch] AscendC GRU 算子加载失败, 回退到原生 nn.GRU:", _e)


class _FusedGRUFunction(torch.autograd.Function):
    """封装 torch.ops.npu.gru / gru_backward。
    注意: 算子仅支持单层、batch_first、无 dropout; 反向不回传输入梯度(x 是数据)。
    """
    @staticmethod
    def forward(ctx, x, w_ih, w_hh, b_ih, b_hh):
        out = torch.ops.npu.gru(x, w_ih, w_hh, b_ih, b_hh)
        ctx.save_for_backward(x, out, w_ih, w_hh, b_ih, b_hh)
        return out

    @staticmethod
    def backward(ctx, grad_out):
        x, out, w_ih, w_hh, b_ih, b_hh = ctx.saved_tensors
        d_w_ih, d_w_hh, d_b_ih, d_b_hh = torch.ops.npu.gru_backward(
            grad_out.contiguous(), x, out, w_ih, w_hh, b_ih, b_hh
        )
        return None, d_w_ih, d_w_hh, d_b_ih, d_b_hh
# ==================== {MARK} end ====================


'''

GRUMODEL_TMPL = '''class GRUModel(nn.Module):
    """已替换为 AscendC 融合 GRU 算子版本 (单算子前向+反向)。
    NPU 上走 torch.ops.npu.gru; 其它设备自动回退原生 nn.GRU。"""

    def __init__(self, d_feat=6, hidden_size=64, num_layers=2, dropout=0.0):
        super().__init__()

        self.use_fused = _NPU_GRU_AVAILABLE
        if self.use_fused and num_layers != 1:
            print(f"[qlib GRU NPU patch] 融合算子仅支持单层, num_layers {num_layers} -> 1")
        self.rnn = nn.GRU(
            input_size=d_feat,
            hidden_size=hidden_size,
            num_layers=1 if self.use_fused else num_layers,
            batch_first=True,
            dropout=dropout,
        )
        self.fc_out = nn.Linear(hidden_size, 1)

        self.d_feat = d_feat

    def forward(self, x):
@PREPROCESS@        if self.use_fused and x.device.type == "npu":
            out = _FusedGRUFunction.apply(
                x.contiguous(),
                self.rnn.weight_ih_l0,
                self.rnn.weight_hh_l0,
                self.rnn.bias_ih_l0,
                self.rnn.bias_hh_l0,
            )
        else:
            out, _ = self.rnn(x)
        return self.fc_out(out[:, -1, :]).squeeze()
'''

PREPROCESS = {
    "gru_plain": (
        "        # x: [N, F*T]\n"
        "        x = x.reshape(len(x), self.d_feat, -1)  # [N, F, T]\n"
        "        x = x.permute(0, 2, 1)  # [N, T, F]\n"
    ),
    "gru_ts": "        # x: [N, T, F] (时序 DataLoader 已切好, 无需 reshape)\n",
}


def patch_common(src, anchor, qlib_file):
    """插入算子加载块 + 设备选择替换 + empty_cache 适配。失败返回 None。"""
    src = src.replace(anchor, PATCH_BLOCK + anchor, 1)

    # 设备选择 cuda -> npu (正则匹配, 兼容不同 qlib 版本的写法)
    dev_pat = re.compile(r"^([ \t]*)self\.device\s*=\s*torch\.device\(.*$", re.M)
    m = dev_pat.search(src)
    if not m:
        print("[ERROR] 未找到 'self.device = torch.device(...)' 代码行，跳过该文件")
        for i, line in enumerate(src.splitlines(), 1):
            if "device" in line:
                print(f"  {i}: {line}")
        return None
    ind = m.group(1)
    new_dev = (
        f"{ind}if GPU >= 0 and _NPU_GRU_AVAILABLE:\n"
        f"{ind}    self.device = torch.device('npu:%d' % GPU)\n"
        f"{ind}    torch.npu.set_device(self.device)\n"
        f"{ind}elif GPU >= 0 and torch.cuda.is_available():\n"
        f"{ind}    self.device = torch.device('cuda:%d' % GPU)\n"
        f"{ind}else:\n"
        f"{ind}    self.device = torch.device('cpu')"
    )
    src = dev_pat.sub(lambda _: new_dev, src, count=1)
    print("[OK] 设备选择已替换为 NPU 优先")

    # empty_cache 适配 NPU
    old_cache = "        if self.use_gpu:\n            torch.cuda.empty_cache()"
    new_cache = (
        "        if self.device.type == 'npu':\n"
        "            torch.npu.empty_cache()\n"
        "        elif self.use_gpu:\n"
        "            torch.cuda.empty_cache()"
    )
    if old_cache in src:
        src = src.replace(old_cache, new_cache, 1)
    else:
        print("[WARN] 未找到 torch.cuda.empty_cache() 位置，跳过（不影响功能）")
    return src


def patch_gru_file(src, variant):
    """整体替换文件末尾的 GRUModel。"""
    gm_anchor = "class GRUModel(nn.Module):"
    idx = src.find(gm_anchor)
    if idx < 0:
        print("[WARN] 未找到 class GRUModel，跳过该文件")
        return None
    tail = src[idx + len(gm_anchor):]
    if re.search(r"^class |^def ", tail, re.M):
        print("[ERROR] GRUModel 之后还存在其它顶层定义，自动截断不安全，跳过该文件")
        return None
    print("[OK] GRUModel 已替换为融合算子版本")
    return src[:idx] + GRUMODEL_TMPL.replace("@PREPROCESS@", PREPROCESS[variant])


def patch_alstm_file(src):
    """定点修改 ALSTMModel: 强制单层 + forward 中 rnn 调用换成融合算子。"""
    # 1) 强制单层 (仅当 rnn_type 为 GRU 时生效, LSTM 分支不受影响)
    old_layer = "self.rnn_layer = num_layers"
    if old_layer not in src:
        print("[WARN] 未找到 self.rnn_layer = num_layers，跳过该文件")
        return None
    new_layer = (
        "if _NPU_GRU_AVAILABLE and rnn_type.upper() == 'GRU' and num_layers != 1:\n"
        "            print(f'[qlib ALSTM NPU patch] 融合算子仅支持单层, num_layers {num_layers} -> 1')\n"
        "            num_layers = 1\n"
        "        self.rnn_layer = num_layers"
    )
    src = src.replace(old_layer, new_layer, 1)

    # 2) forward 中 rnn 调用换成融合算子
    old_call = "rnn_out, _ = self.rnn(self.net(inputs))"
    if old_call not in src:
        print("[WARN] 未找到 rnn 调用行，跳过该文件")
        return None
    new_call = (
        "_rnn_in = self.net(inputs)\n"
        "        if _NPU_GRU_AVAILABLE and _rnn_in.device.type == 'npu' and isinstance(self.rnn, nn.GRU):\n"
        "            rnn_out = _FusedGRUFunction.apply(\n"
        "                _rnn_in.contiguous(),\n"
        "                self.rnn.weight_ih_l0,\n"
        "                self.rnn.weight_hh_l0,\n"
        "                self.rnn.bias_ih_l0,\n"
        "                self.rnn.bias_hh_l0,\n"
        "            )\n"
        "        else:\n"
        "            rnn_out, _ = self.rnn(_rnn_in)"
    )
    src = src.replace(old_call, new_call, 1)
    print("[OK] ALSTMModel 的 GRU 调用已替换为融合算子版本")
    return src


def patch_one(qlib_file, variant, anchor):
    print(f"--- 处理 {os.path.basename(qlib_file)} ({variant} 变体) ---")
    src = open(qlib_file, encoding="utf-8").read()
    if MARK in src:
        print("[SKIP] 已打过补丁，无需重复执行")
        return True
    if anchor not in src:
        print(f"[WARN] 未找到锚点 {anchor}，跳过该文件")
        return False

    # 备份
    bak = qlib_file + ".bak_算子替换"
    if not os.path.exists(bak):
        shutil.copy2(qlib_file, bak)
    print(f"原文件已备份: {bak}")

    src = patch_common(src, anchor, qlib_file)
    if src is None:
        return False
    if variant.startswith("gru"):
        src = patch_gru_file(src, variant)
    else:
        src = patch_alstm_file(src)
    if src is None:
        return False

    open(qlib_file, "w", encoding="utf-8").write(src)
    print(f"[OK] {os.path.basename(qlib_file)} 补丁写入完成")
    return True


results = []
for fname, variant, anchor in TARGETS:
    path = os.path.join(model_dir, fname)
    if not os.path.isfile(path):
        print(f"[SKIP] {fname} 不存在")
        continue
    results.append(patch_one(path, variant, anchor))

if not results or not any(results):
    print("[ERROR] 没有任何文件被成功补丁")
    sys.exit(1)
PYEOF

# -----------------------------------------------------------------------------
# 5. 数值正确性校验：融合算子 vs 原生 nn.GRU（前向 + 反向）
# -----------------------------------------------------------------------------
if [ "$RUN_VERIFY" = "1" ]; then
    log "5/5 数值校验 (NPU 融合算子 vs CPU 原生 nn.GRU)"
    SO_PATH="$SO_PATH" $PYTHON - <<'PYEOF'
import os
import torch
import torch_npu  # noqa: F401
import torch.nn as nn

torch.ops.load_library(os.environ["SO_PATH"])
torch.manual_seed(42)

B, S, I, H = 8, 60, 6, 64
# 注意: 部分 torch_npu 版本在 NPU 上没有原生 GRU 的 aclnn 实现,
# 因此标准答案放在 CPU 上用 nn.GRU 计算 (数学等价, fp32 跨设备误差极小)。
rnn_cpu = nn.GRU(I, H, num_layers=1, batch_first=True)
x_cpu = torch.randn(B, S, I)

# ---- 前向对比 ----
ref, _ = rnn_cpu(x_cpu)
dev = "npu:0"
x = x_cpu.to(dev)
w_ih = rnn_cpu.weight_ih_l0.detach().to(dev).contiguous()
w_hh = rnn_cpu.weight_hh_l0.detach().to(dev).contiguous()
b_ih = rnn_cpu.bias_ih_l0.detach().to(dev).contiguous()
b_hh = rnn_cpu.bias_hh_l0.detach().to(dev).contiguous()

out = torch.ops.npu.gru(x, w_ih, w_hh, b_ih, b_hh)
fwd_err = (out.cpu() - ref).abs().max().item()
print(f"前向最大误差: {fwd_err:.3e}")
assert fwd_err < 5e-4, "前向误差过大，请检查算子与芯片型号是否匹配"

# ---- 反向对比（权重梯度）----
g_cpu = torch.randn_like(ref)
ref.backward(g_cpu)
ref_grads = [rnn_cpu.weight_ih_l0.grad.clone(), rnn_cpu.weight_hh_l0.grad.clone(),
             rnn_cpu.bias_ih_l0.grad.clone(), rnn_cpu.bias_hh_l0.grad.clone()]

dw_ih, dw_hh, db_ih, db_hh = torch.ops.npu.gru_backward(
    g_cpu.to(dev).contiguous(), x, out, w_ih, w_hh, b_ih, b_hh)
for name, a, b in zip(["dW_ih", "dW_hh", "db_ih", "db_hh"],
                      [dw_ih, dw_hh, db_ih, db_hh], ref_grads):
    err = (a.cpu() - b).abs().max().item()
    rel = err / (b.abs().max().item() + 1e-8)
    print(f"反向 {name}: 最大绝对误差 {err:.3e}, 相对误差 {rel:.3e}")
    assert rel < 1e-2, f"{name} 梯度误差过大"

print("[OK] 数值校验通过，替换完成！")
PYEOF
    log "全部完成 ✅"
else
    log "5/5 已跳过数值校验 (RUN_VERIFY=0)"
fi

cat <<EOF

=============================================================================
完成！使用说明:
  - qlib 配置中 GRU 模型的 GPU 参数现在代表 NPU 卡号 (如 GPU: 0 -> npu:0)
  - 融合算子仅支持单层 GRU, num_layers 会被强制为 1
  - 如需恢复原版 qlib (pytorch_gru.py 和 pytorch_gru_ts.py 均已备份):
      for f in pytorch_gru.py pytorch_gru_ts.py pytorch_alstm.py pytorch_alstm_ts.py; do
          [ -f "$MODEL_DIR/$f.bak_算子替换" ] && cp "$MODEL_DIR/$f.bak_算子替换" "$MODEL_DIR/$f"
      done
  - 如需指定其它 .so 路径, 设置环境变量 GRU_EXT_SO
=============================================================================
EOF
