import fire
import torch
import torch_npu
from qlib.cli.run import run


print("=" * 40)
print("torch_npu 可用:", torch.npu.is_available())
print("NPU 卡数:", torch.npu.device_count())
print("当前卡:", torch.npu.get_device_name(0) if torch.npu.is_available() else "无")
print("=" * 40)



if __name__ == "__main__":
    fire.Fire(run)
