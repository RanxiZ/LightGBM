#!/usr/bin/env bash
# =============================================================================
# qlib GRU 算子升级脚本：基线版 -> 进化版 (GRU_evo_20261012_110616_final, 2.05x)
#
# 前提: 已用 qlib_AscendC_GRU.sh 完成过 qlib 补丁 (GRU/ALSTM 走 torch.ops.npu.gru)
# 原理: 进化版算子接口与基线完全一致, qlib 补丁代码不用动, 只替换 .so 产物
#
# 用法:
#   bash qlib_AscendC_GRU_evo.sh [选项]
#   bash qlib_AscendC_GRU_evo.sh --rollback     # 回滚到基线算子
#
# 选项:
#   --soc <型号>          芯片型号, 不传则 npu-smi 自动探测 (如 Ascend950DT_9582)
#   --ascend-home <路径>  CANN 路径 (默认 /usr/local/Ascend/ascend-toolkit/latest)
#   --python <路径>       python 解释器 (默认 python3, 须装了 torch/torch_npu/qlib)
#   --workdir <路径>      工作目录 (默认 ~/ascendc_gru)
#   --repo-url <地址>     仓库地址 (默认 https://github.com/Liziqi-77/AI-Infra.git)
#   --no-verify           跳过数值校验
#   --rollback            回滚: 恢复基线 .so 后退出
#   -h, --help            帮助
# =============================================================================
set -euo pipefail

usage() { sed -n '2,27p' "$0" | sed 's/^# \{0,1\}//'; exit 0; }

log()  { echo -e "\033[1;32m[STEP]\033[0m $*"; }
warn() { echo -e "\033[1;33m[WARN]\033[0m $*"; }
die()  { echo -e "\033[1;31m[ERROR]\033[0m $*" >&2; exit 1; }

# ---------- npu-smi 自动探测 SOC (与 qlib_AscendC_GRU.sh 相同逻辑) ----------
detect_soc() {
    command -v npu-smi >/dev/null 2>&1 || return 1
    local nid info chip ctype npu
    nid=$(npu-smi info -l 2>/dev/null | grep -m1 'NPU ID' | cut -d: -f2 | tr -d ' ')
    [ -n "$nid" ] || return 1
    info=$(npu-smi info -t board -i "$nid" 2>/dev/null)
    chip=$(echo "$info" | grep -m1 'Chip Name' | cut -d: -f2 | tr -d ' ')
    npu=$(echo "$info" | grep -m1 'NPU Name' | cut -d: -f2 | tr -d ' ')
    if [ -z "$chip" ]; then
        info=$(npu-smi info -t board -i "$nid" -c 0 2>/dev/null)
        chip=$(echo "$info" | grep -m1 'Chip Name' | cut -d: -f2 | tr -d ' ')
        ctype=$(echo "$info" | grep -m1 'Chip Type' | cut -d: -f2 | tr -d ' ')
        npu=$(echo "$info" | grep -m1 'NPU Name' | cut -d: -f2 | tr -d ' ')
    fi
    [ -n "$chip" ] || return 1
    case "$chip" in
        Ascend*) : ;;
        *)       chip="${ctype:-Ascend}${chip}" ;;
    esac
    case "$chip" in
        *950*|*910_93*) [ -n "$npu" ] && chip="${chip}_${npu}" ;;
    esac
    chip=$(echo "$chip" | sed -E 's/^ascend/Ascend/I; s/950dt/950DT/I; s/950pr/950PR/I; s/910b/910B/I; s/310p/310P/I')
    [ -n "$chip" ] && echo "$chip"
}

# ------------------------------ 参数解析 ------------------------------------
WORKDIR="${WORKDIR:-$HOME/ascendc_gru}"
SOC_VERSION="${SOC_VERSION:-}"
ASCEND_HOME_PATH="${ASCEND_HOME_PATH:-/usr/local/Ascend/ascend-toolkit/latest}"
PYTHON="${PYTHON:-python3}"
REPO_URL="${REPO_URL:-https://github.com/Liziqi-77/AI-Infra.git}"
EVO_SUBDIR="AscendC_ops/GRU_evo_20261012_110616_final"
BASE_SUBDIR="AscendC_ops/NN_GRU_ascendc_build/kernel"
RUN_VERIFY=1
ROLLBACK=0

while [ $# -gt 0 ]; do
    case "$1" in
        --soc)         SOC_VERSION="$2"; shift 2 ;;
        --ascend-home) ASCEND_HOME_PATH="$2"; shift 2 ;;
        --python)      PYTHON="$2"; shift 2 ;;
        --workdir)     WORKDIR="$2"; shift 2 ;;
        --repo-url)    REPO_URL="$2"; shift 2 ;;
        --no-verify)   RUN_VERIFY=0; shift ;;
        --rollback)    ROLLBACK=1; shift ;;
        -h|--help)     usage ;;
        *) echo "[ERROR] 未知参数: $1 (用 --help 查看用法)" >&2; exit 1 ;;
    esac
done

export ASCEND_HOME_PATH
if [ -f "$ASCEND_HOME_PATH/../set_env.sh" ]; then
    # shellcheck disable=SC1091
    source "$ASCEND_HOME_PATH/../set_env.sh"
elif [ -f /usr/local/Ascend/ascend-toolkit/set_env.sh ]; then
    # shellcheck disable=SC1091
    source /usr/local/Ascend/ascend-toolkit/set_env.sh
fi
export ASCEND_HOME_PATH

# ---------- 定位 qlib 补丁里写死的默认 .so 路径 (切换/回滚都靠它) -----------
get_default_so() {
    # -I: 隔离模式, 避免当前目录的 qlib 源码副本 shadow 掉 site-packages 里的补丁版
    "$PYTHON" -I - <<'PYEOF'
import importlib.util, os, re, sys
spec = importlib.util.find_spec("qlib")
if spec is None or not spec.submodule_search_locations:
    sys.stderr.write("原因: 该 python 环境里找不到 qlib 包\n")
    raise SystemExit(1)
d = os.path.join(list(spec.submodule_search_locations)[0], "contrib", "model")
sys.stderr.write(f"qlib 模型目录: {d}\n")
pat = re.compile(
    r"_GRU_EXT_SO\s*=\s*_os\.environ\.get\(\s*['\"]GRU_EXT_SO['\"]\s*,\s*r?['\"]([^'\"]+)['\"]"
)
found_patch = False
for name in ["pytorch_gru_ts.py", "pytorch_gru.py", "pytorch_alstm_ts.py", "pytorch_alstm.py"]:
    p = os.path.join(d, name)
    if os.path.isfile(p):
        src = open(p, encoding="utf-8").read()
        if "AscendC fused GRU patch" in src:
            found_patch = True
        m = pat.search(src)
        if m:
            print(m.group(1))
            raise SystemExit(0)
sys.stderr.write("原因: " + ("补丁存在但 _GRU_EXT_SO 行格式不匹配\n" if found_patch
                           else "补丁标记不存在 (未运行过 qlib_AscendC_GRU.sh?)\n"))
raise SystemExit(1)
PYEOF
}

DEFAULT_SO="$(get_default_so 2>/tmp/evo_diag || true)"
if [ -z "$DEFAULT_SO" ]; then
    warn "无法从 qlib 补丁解析默认 .so 路径 (python=$PYTHON)，诊断信息:"
    cat /tmp/evo_diag 2>/dev/null || true
    # 回退方案: 使用 workdir 下基线算子的编译产物路径
    DEFAULT_SO="$(ls "$WORKDIR/AI-Infra/$BASE_SUBDIR"/build/gru_ext*.so 2>/dev/null | head -n 1 || true)"
    [ -n "$DEFAULT_SO" ] && log "回退使用基线编译产物路径: $DEFAULT_SO"
fi
[ -n "$DEFAULT_SO" ] || die "仍无法确定默认 .so 路径。
  1) 请用装了 qlib 的解释器: --python /usr/local/python3.12.13/bin/python
  2) 请确认已先运行过 qlib_AscendC_GRU.sh 完成补丁"
log "qlib 当前默认算子: $DEFAULT_SO"

# ============================== 回滚模式 ====================================
if [ "$ROLLBACK" = "1" ]; then
    BAK="${DEFAULT_SO}.baseline_bak"
    [ -f "$BAK" ] || die "找不到基线备份 $BAK (可能从未升级过, 无需回滚)"
    cp -f "$BAK" "$DEFAULT_SO"
    log "已回滚到基线算子: $BAK -> $DEFAULT_SO"
    warn "建议重跑一次 qlib GRU 短训练确认回滚生效"
    exit 0
fi

# ============================ 步骤 1: 依赖检查 ==============================
log "1/6 检查依赖"
command -v cmake >/dev/null || die "缺少 cmake"
command -v make  >/dev/null || die "缺少 make"
command -v git   >/dev/null || die "缺少 git"
$PYTHON -c "import torch, torch_npu" 2>/dev/null || die "$PYTHON 环境缺少 torch/torch_npu"
[ -f "$DEFAULT_SO" ] || warn "当前默认 .so 不存在: $DEFAULT_SO (首次升级时旧算子应已编译过)"

if [ -z "$SOC_VERSION" ]; then
    SOC_VERSION="$(detect_soc || true)"
    [ -n "$SOC_VERSION" ] || die "无法自动探测芯片型号，请用 --soc 手动指定"
fi
# 规范化大小写 (容器 Docker ENV 可能自带小写值如 ascend950dt_9582)
SOC_VERSION=$(echo "$SOC_VERSION" | sed -E 's/^ascend/Ascend/I; s/950dt/950DT/I; s/950pr/950PR/I; s/910b/910B/I; s/310p/310P/I')
log "SOC_VERSION=$SOC_VERSION"
case "$SOC_VERSION" in
    *950*) : ;;
    *) warn "进化版算子针对 Ascend 950 (arch35/dav-c310) 开发, 当前 $SOC_VERSION 可能不适用" ;;
esac

# ========================== 步骤 2: 拉取进化版源码 ===========================
log "2/6 拉取进化版算子源码"
mkdir -p "$WORKDIR"
if [ ! -d "$WORKDIR/AI-Infra/.git" ]; then
    git clone --depth 1 --filter=blob:none --sparse "$REPO_URL" "$WORKDIR/AI-Infra"
    git -C "$WORKDIR/AI-Infra" sparse-checkout set "$EVO_SUBDIR"
else
    git -C "$WORKDIR/AI-Infra" sparse-checkout add "$EVO_SUBDIR" 2>/dev/null \
        || git -C "$WORKDIR/AI-Infra" sparse-checkout set "$EVO_SUBDIR" "$BASE_SUBDIR"
fi
EVO_DIR="$WORKDIR/AI-Infra/$EVO_SUBDIR"
[ -d "$EVO_DIR/kernel" ] || die "进化版源码不完整: $EVO_DIR"

# ============================ 步骤 3: 构建算子 ===============================
log "3/6 构建进化版算子"
# python3 shim: build_a5.sh 内部写死 python3, 指向 --python 传入的解释器
SHIM_DIR="$WORKDIR/.pyshim"
mkdir -p "$SHIM_DIR"
PYTHON_BIN="$(command -v "$PYTHON" || true)"
[ -n "$PYTHON_BIN" ] || die "找不到解释器: $PYTHON"
ln -sf "$PYTHON_BIN" "$SHIM_DIR/python3"
ln -sf "$PYTHON_BIN" "$SHIM_DIR/python"
export PATH="$SHIM_DIR:$PATH"
log "python3 -> $PYTHON_BIN"

# 修正 build_a5.sh 里的 SOC_VERSION 为本机实测值 (README 警告: 用错会静默编出错架构内核)
# 注意配对处理引号, 避免产生 `SOC_VERSION=xxx"` 这种断引号
if [ -f "$EVO_DIR/kernel/build_a5.sh" ]; then
    sed -i -E "s/(SOC_VERSION=)[\"']?[A-Za-z0-9_.]+[\"']?/\1\"$SOC_VERSION\"/g" "$EVO_DIR/kernel/build_a5.sh"
    bash -n "$EVO_DIR/kernel/build_a5.sh" || die "build_a5.sh 语法异常, 请检查该文件 SOC_VERSION 行"
    grep -n "SOC_VERSION" "$EVO_DIR/kernel/build_a5.sh" | head -3 || true
    export SOC_VERSION
    (cd "$EVO_DIR/kernel" && bash build_a5.sh --clean)
else
    warn "未找到 build_a5.sh, 回退到通用 cmake 构建"
    export SOC_VERSION
    mkdir -p "$EVO_DIR/kernel/build"
    cmake -S "$EVO_DIR/kernel" -B "$EVO_DIR/kernel/build" \
        -DSOC_VERSION="$SOC_VERSION" \
        -DASCEND_CANN_PACKAGE_PATH="$ASCEND_HOME_PATH" \
        -DCMAKE_BUILD_TYPE=Release
    make -C "$EVO_DIR/kernel/build" -j"$(nproc)"
fi

NEW_SO="$(ls "$EVO_DIR"/kernel/build/gru_ext*.so 2>/dev/null | head -n 1)"
[ -n "$NEW_SO" ] || die "构建完成但未找到 gru_ext*.so, 请检查上方编译日志"
log "进化版算子构建成功: $NEW_SO"

# ====================== 步骤 4: 算子级验证 (尽力而为) ========================
if [ "$RUN_VERIFY" = "1" ]; then
    log "4/6 算子级验证 (verify_and_bench.py, 失败不阻断, 以步骤 6 金标校验为准)"
    if [ -f "$EVO_DIR/verify_and_bench.py" ]; then
        (cd "$EVO_DIR" && "$SHIM_DIR/python3" verify_and_bench.py) \
            || warn "verify_and_bench.py 未通过或缺 golden 数据 (可尝试先跑 gen_golden.py), 继续以金标校验为准"
    else
        warn "verify_and_bench.py 不存在, 跳过"
    fi
else
    warn "4/6 已跳过 (--no-verify)"
fi

# ====================== 步骤 5: 切换 qlib 到进化版算子 =======================
log "5/6 切换 qlib 默认算子"
BAK="${DEFAULT_SO}.baseline_bak"
if [ ! -f "$BAK" ] && [ -f "$DEFAULT_SO" ]; then
    cp -f "$DEFAULT_SO" "$BAK"
    log "基线算子已备份: $BAK"
fi
cp -f "$NEW_SO" "$DEFAULT_SO"
log "已切换: $NEW_SO -> $DEFAULT_SO"
warn "若你的运行环境显式设置了 GRU_EXT_SO 环境变量, 请同步改为: $NEW_SO"

# ====================== 步骤 6: 金标数值校验 (NPU vs CPU) ====================
if [ "$RUN_VERIFY" = "1" ]; then
    log "6/6 金标数值校验 (新算子 on NPU vs CPU nn.GRU)"
    "$SHIM_DIR/python3" - <<PYEOF
import torch
import torch_npu  # noqa: F401
import torch.nn as nn

torch.ops.load_library("$DEFAULT_SO")
torch.manual_seed(42)

B, S, I, H = 8, 60, 6, 64
rnn_cpu = nn.GRU(I, H, num_layers=1, batch_first=True)
x_cpu = torch.randn(B, S, I)
ref, _ = rnn_cpu(x_cpu)

dev = "npu:0"
x = x_cpu.to(dev)
w = [p.detach().to(dev).contiguous() for p in
     [rnn_cpu.weight_ih_l0, rnn_cpu.weight_hh_l0, rnn_cpu.bias_ih_l0, rnn_cpu.bias_hh_l0]]
out = torch.ops.npu.gru(x, *w)
fwd_err = (out.cpu() - ref).abs().max().item()
print(f"前向最大误差: {fwd_err:.3e}")
assert fwd_err < 5e-4, "前向误差过大"

g_cpu = torch.randn_like(ref)
ref.backward(g_cpu)
ref_grads = [p.grad.clone() for p in
             [rnn_cpu.weight_ih_l0, rnn_cpu.weight_hh_l0, rnn_cpu.bias_ih_l0, rnn_cpu.bias_hh_l0]]
grads = torch.ops.npu.gru_backward(g_cpu.to(dev).contiguous(), x, out, *w)
# 注意: 进化版反向为 fp16 混合精度, 判据放宽到 rel < 1e-2 (README: rel_l2 约 6e-4)
for name, a, b in zip(["dW_ih", "dW_hh", "db_ih", "db_hh"], grads, ref_grads):
    rel = (a.cpu() - b).abs().max().item() / (b.abs().max().item() + 1e-8)
    print(f"反向 {name}: 相对误差 {rel:.3e}")
    assert rel < 1e-2, f"{name} 梯度误差过大"
print("[OK] 金标校验通过, 升级完成!")
PYEOF
    log "全部完成 ✅  回滚命令: bash $0 --rollback --python $PYTHON"
else
    warn "6/6 已跳过 (--no-verify), 请自行验证后再投入使用"
fi
